package com.example.p3_pinzon_r;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.EventLogTags;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PointOfInterest;

import java.util.Locale;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback { //La classe OnMapReadyCallback fa que

    private GoogleMap mMap; //variable de classe tipo GoogleMap.
    private static final int REQUEST_LOCATION_PERMISSION=1;
    private ImageButton button_mapa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps); //carreguem el mapa en un fragment.

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map); //carreguem el contingut. El mapa es un fragment.

        button_mapa = findViewById(R.id.buttonMapa);
        mapFragment.getMapAsync(this); //carrega el fragment en un thread perque vagi mes rapid al carregar el mapa.location

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.map_options, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Change the map type based on the user's selection.
        switch (item.getItemId()) {
            case R.id.normal_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                return true;
            case R.id.hybrid_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                return true;
            case R.id.satellite_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                return true;
            case R.id.terrain_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
    /*
        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(41.5653396, 2.0232824); //Objecte de tipus latitu/longitud, aqui canviem els parametres per canvir la ubicacio.
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney")); //Aixo crea el marcador de la posicio establerta en el objecte latitud/longitud.
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney)); //Canvia la camara per situars a sobre de la ubicacio esscollida i el seu Zoom.
    */

    mMap.getUiSettings().setZoomControlsEnabled(true);


    LatLng home =new LatLng(41.5653396, 2.0232824);
    float zoom = 13;
    mMap.addMarker(new MarkerOptions().position(home).title("casa"));
    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(home, zoom));
    setMapLongClick(mMap);
    setPoiClick(mMap);
    setMapStyle(mMap);
    enableMyLocation();

    }

    private void setMapStyle(GoogleMap map){
       try{
           boolean success= map.setMapStyle(MapStyleOptions.loadRawResourceStyle(this,R.raw.map_style));
           if(!success){
               Log.e("TAG","Style parsing failed.");
           }
       }catch(Resources.NotFoundException e){
           Log.e("TAG","Can't find style",e);
       }
    }

    private void setMapLongClick(final GoogleMap map){
        map.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener(){
            @Override
            public void onMapLongClick(LatLng latLng){
                String snippet = String.format(Locale.getDefault(),"Lat:%1$.5f, Long: %2$.5f",latLng.latitude,latLng.longitude);

            map.addMarker(new MarkerOptions()
                    .position(latLng)
                    .title("ricard") //titol del marcador
                    .snippet(snippet)); //Mostra la latitud i longitud en lletra petita quan coloquem un marcador i fem click a sobre.
            }

        });

    }


    private void setPoiClick(final GoogleMap map){
        map.setOnPoiClickListener(new GoogleMap.OnPoiClickListener(){
            @Override
            public void onPoiClick(PointOfInterest poi){
                Marker poiMarker = mMap.addMarker(new MarkerOptions().position(poi.latLng).title(poi.name));
                poiMarker.showInfoWindow();
                poiMarker.setTag(getString(R.string.poi));
            }
        });

    }

    private void enableMyLocation(){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED){
                mMap.setMyLocationEnabled(true);
                //mMap.isMyLocationEnabled();
        }else{
            ActivityCompat.requestPermissions(this,new String[]
                    {Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,@NonNull int[] grantResults){
        switch(requestCode){
            case REQUEST_LOCATION_PERMISSION:
                if(grantResults.length > 0 && grantResults[0]== PackageManager.PERMISSION_GRANTED){
                    enableMyLocation();
                    break;
                }
        }
    }


}
//Els botons de augmentar/allunyar zoom i els botons de punts cardinals no es mostren x defecte, s'ha de fer.